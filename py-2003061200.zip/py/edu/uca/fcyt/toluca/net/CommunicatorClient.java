/*
 * XmlPackageSessionTest.java
 *
 * Created on 25 de marzo de 2003, 07:03 PM
 */

package py.edu.uca.fcyt.toluca.net;

import py.edu.uca.fcyt.toluca.*;
import py.edu.uca.fcyt.toluca.table.*;
import py.edu.uca.fcyt.toluca.game.*;
import py.edu.uca.fcyt.game.*;

import py.edu.uca.fcyt.toluca.event.*;

import py.edu.uca.fcyt.net.*;

import java.util.*;
import org.jdom.*;
import java.net.*;
import java.io.*;
import org.jdom.output.XMLOutputter;
/**
 *
 * @author  PABLO JAVIER
 */
public class CommunicatorClient extends Communicator {
    
    RoomClient pieza;
    private TrucoPlayer mi_jugador=null;    // Este es el que hay que usar como referencia al jugador representado!!!
    /** Creates a new instance of XmlPackageSessionTest */
    ChatPanelContainer Chatpanel;
    
    /** Holds value of property player. */
    private TrucoPlayer player;
    
    public CommunicatorClient(RoomClient pieza) {
        super();
        this.pieza = pieza;
        int retinit = init();
        System.out.println(getInitErrorMessage(retinit));
        pieza.addRoomListener(this);
    }
    
    public CommunicatorClient() {
        super();
        int retinit = init();
        System.out.println(getInitErrorMessage(retinit));
    }
    public String getInitErrorMessage(int errcode) {
        return "Sin errores";
    }
    
    public int init() {
        int ret = -1;
        try {
            //setSocket(new Socket("interno.roshka.com.py", 6767));
            setSocket(new Socket("localhost", 6767));
            ret = XmlPackagesSession.XML_PACKAGE_SESSION_INIT_OK;
        } catch (UnknownHostException e) {
            ret = -5;
        } catch (IOException e) {
            ret = -4;
        }
        return ret;
    }
    
    public void receiveXmlPackage(Element xmlPackage) {
        System.err.println("//////////////////////////////////////////");
        System.out.println("Vino un paquete: " + xmlPackage.getName());
        Document doc=new Document(xmlPackage);
        try {
            
            XMLOutputter serializer = new XMLOutputter("  ", true);
            
            serializer.output(doc, System.out);
            
        }
        catch (IOException e) {
            System.err.println(e);
        }
        System.err.println("//////////////////////////////////////////");
        cabecera(doc);
        //chat.agregar(xmlPackage.getChild("Usuario").getText() + ": " + xmlPackage.getChild("Mensaje").getText());
        
    }
    
    public void sendXmlPackage(String option,RoomEvent te) {
        
    }
    
    public void receiveXmlPackageWithParsingError(String rawXmlPackage) {
        System.out.println("El XML tiene errores:\n" + rawXmlPackage);
    }
    
    public void loginRequested(RoomEvent te){
        //peticion de loginc
        Document doc;
        doc = super.xmlCreateLogin(te);
        /*try {
         
            XMLOutputter serializer = new XMLOutputter("  ", true);
         
            serializer.output(doc, System.out);
         
        }
        catch (IOException e) {
            System.err.println(e);
        }*/
        
        super.sendXmlPackage(doc);
    }
    public void chatMessageRequested(ChatPanelContainer chatPanelContainer, TrucoPlayer jug, String htmlMessage){
        Document doc;
        //this.ChatPanel=panel;
        doc=super.xmlCreateChatMsg(chatPanelContainer, jug,htmlMessage);
        super.sendXmlPackage(doc);
    }
    
    public  void xmlReadChatMsg(Object o) {
        String aux;
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            if(aux.compareTo("Player")==0) {
                //System.out.println("PLAYER:"+element.getText());
                user=element.getAttributeValue("name");
            }
            if(aux.compareTo("Msg")==0) {
                //System.out.println("MESSAGE:"+element.getText());
                message=element.getText();
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadChatMsg(child);
            }
            if(aux.compareTo("ChatMsg")==0) {
                //Chatpanel.showChatMessage(user,message);
                System.out.println("Player: "+user);
                System.out.println("Mensaje: "+message);
                // Aca vemos para qui�n puta es el mensaje
                String origen = element.getAttributeValue("origin");
                System.out.println("El origen es: " + origen);
                if (origen.equalsIgnoreCase("room")) {
                    pieza.showChatMessage(new TrucoPlayer(user, 0), message);
                } else {
                    Table t = (Table)getTables().get(origen);
                    if (t != null) {
                        t.showChatMessage(new TrucoPlayer(user,0), message);
                    } else {
                        System.out.println("NO PUDIMOS ENTREGAR EL CHAT!!! !@@!#$#@@Q");
                    }
                }
            }
        }
    }
    
    public void tableCreated(RoomEvent re) {
        // Problemas de diseno a resolver en TolucaV2
        
    }
    int typeAux;
    int tantoAux;
    public void xmlReadCantarTanto(Object o) {
        String aux;
        
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            if(aux.compareTo("Type")==0) {
                typeAux=Integer.parseInt(element.getAttributeValue("id"));
                
            }
            if(aux.compareTo("Table")==0) {
                //System.out.println("MESSAGE:"+element.getText());
                tableIdAux=Integer.parseInt(element.getAttributeValue("id"));
                
            }
            if(aux.compareTo("Hand")==0) {
                handAux=Integer.parseInt(element.getAttributeValue("number"));
                
            }
            if(aux.compareTo("Player")==0) {
                //System.out.println("PLAYER:"+element.getText());
                userAux=element.getAttributeValue("name");
                
            }
            if(aux.compareTo("Tanto")==0) {
                tantoAux=Integer.parseInt(element.getAttributeValue("tanto"));
                
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                
                xmlReadCantarTanto(child);
            }
            if(aux.compareTo("CantarTanto")==0) {
                TrucoEvent te=new TrucoEvent(tableIdAux,handAux,mi_jugador,(byte)typeAux,tantoAux);
                System.out.println("Table id : "+te.getTableNumber());
                System.out.println("HAND : "+te.getNumberOfHand());
                System.out.println("Truco Player : "+te.getTrucoPlayer().getName());
                System.out.println("TYPE  : "+te.getTypeEvent());
                System.out.println("El value es : "+te.getValue());
                        /*	try {
                                                    String tableid=String.valueOf(tableIdAux);
                                                    Table tabela = (Table)getTables().get(tableid);
                                                        TrucoGameClient trucoGame=(TrucoGameClient)tabela.getTGame();
                                                        trucoGame.play(te);
                                        } catch (java.lang.NullPointerException e) {
                                                        System.err.println("LA TABLA ES NULL EN EL COMUNICATOR CLIENT METODO xmlReadCantarTanto ");
                                                        e.printStackTrace();
                                                                throw e;
                                                        }*/
                
            }
        }
    }
    int valueAux;
    public void xmlReadTrucoPlay(Object o) {
        String aux;
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            if(aux.compareTo("Type")==0) {
                typeAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            if(aux.compareTo("Table")==0) {
                //System.out.println("MESSAGE:"+element.getText());
                tableIdAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            
            if(aux.compareTo("Player")==0) {
                //System.out.println("PLAYER:"+element.getText());
                userAux=element.getAttributeValue("name");
            }
            if(aux.compareTo("Carta")==0) {
                String kind=element.getAttributeValue("kind");
                String value=element.getAttributeValue("value");
                cardAux=new TrucoCard(Integer.parseInt(kind),Integer.parseInt(value));
            }
            if(aux.compareTo("Value")==0) {
                
                valueAux=Integer.parseInt(element.getAttributeValue("val"));
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadTrucoPlay(child);
            }
            if(aux.compareTo("TrucoPlay")==0) {
                //CUANDO SE CREA ESTE TRUCOPLAY HAY QUE PASARLE LA REFENCIA AL PLAYER CORRESPONDIENTE
                //CREEMOS QUE PODEMOS SACAR DE LA TABLA PERO HAY QUE VER
                TrucoPlay tp=new TrucoPlay(tableIdAux,new TrucoPlayer(userAux),(byte)typeAux,cardAux,valueAux);
                
                System.out.println("Tabla :"+ tp.getTableNumber());
                System.out.println("Truco Player : "+tp.getPlayer().getName());
                System.out.println("TYPE  : "+tp.getType());
                System.out.println("LA CARTA   PALO = "+tp.getCard().getKind()+" El valor es "+tp.getCard().getValue());
                System.out.println("El valor es " + tp.getValue());
                
                                        /*	try {
                                         
                                                    String tableid=String.valueOf(tableIdAux);
                                                    Table tabela = (Table)getTables().get(tableid);
                                                        TrucoGameClient trucoGame=(TrucoGameClient)tabela.getTGame();
                                                        trucoGame.play(te);
                                        } catch (java.lang.NullPointerException e) {
                                                        System.err.println("LA TABLA ES NULL EN EL COMUNICATOR CLIENT METODO xmlReadCantarTanto ");
                                                        e.printStackTrace();
                                                                throw e;
                                        }*/
            }
        }
    }
    private void cabecera(Document doc) {//saca la cabeza del paquete y envia el paquete al lector correspondiente
        
        List children = doc.getContent();
        Iterator iterator = children.iterator();
        Object child = iterator.next();
        Element element = (Element) child;
        String aux=element.getName();
        //System.out.println(aux);
        
        
        if(aux.compareTo("PlayerSit")==0) {
            //cuando ya se sento un Player
            xmlReadPlayerSit(child);
        }
        if(aux.compareTo("ChatMsg")==0) {
            System.out.println("Llego un mensaje de chat, soy " + player.getName());
            xmlReadChatMsg(child);
        }
        
        if(aux.compareTo("LoginOk")==0) {
            System.out.println("LLego un mensaje de LoginOk");
            xmlReadLoginOk(child);
        }
        if(aux.compareTo("UserJoined")==0){
            System.out.println("Llego un mensaje de UserJoined");
            xmlReadUserJoined(child);
        }
        
        if(aux.compareTo("Turno")==0) {
            super.xmlReadTurno(child);
        }
        if(aux.compareTo("TerminalMessage")==0) {
            //super.xmlReadTerminalMessage(child);
        }
        
        if(aux.compareTo("TableCreated")==0) {
            //cuando ya se creo una tabla
            xmlReadTableCreated(child);
        }
        if(aux.compareTo("TableJoined")==0) {
            //cuando ya se creo una tabla
            xmlReadTableJoined(child);
        }
        if(aux.compareTo("GameStarted")==0) {
            //cuando empezo el juego
            xmlReadGameStarted(child);
        }
        if(aux.compareTo("SendCards")==0) {
            //cuando se envia tres cartas
            xmlreadSendCards(child);
        }
        if(aux.compareTo("CantarTanto")==0) {
            //cuando se canta el tanto
            xmlReadCantarTanto(child);
        }
        if(aux.compareTo("Canto")==0) {
            //cuando se canta
            xmlReadCanto(child);
        }
        if(aux.compareTo("Cardsend")==0){
            //cuando se envia una carta
            xmlReadCard(child);
        }
        if(aux.compareTo("TrucoPlay")==0){
            xmlReadTrucoPlay(child);
        }
    }
    TrucoCard cardAux;
    public void xmlReadCard(Object o) {
        String aux;
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            if(aux.compareTo("Type")==0) {
                typeAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            if(aux.compareTo("Table")==0) {
                //System.out.println("MESSAGE:"+element.getText());
                tableIdAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            if(aux.compareTo("Hand")==0) {
                handAux=Integer.parseInt(element.getAttributeValue("number"));
            }
            if(aux.compareTo("Player")==0) {
                //System.out.println("PLAYER:"+element.getText());
                userAux=element.getAttributeValue("name");
            }
            if(aux.compareTo("Carta")==0) {
                String kind=element.getAttributeValue("kind");
                String value=element.getAttributeValue("value");
                cardAux=new TrucoCard(Integer.parseInt(kind),Integer.parseInt(value));
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadCard(child);
            }
            if(aux.compareTo("Cardsend")==0) {
                TrucoEvent te=new TrucoEvent(tableIdAux,handAux,mi_jugador,(byte)type,cardAux);
                
                System.out.println("Tabla :"+ te.getTableNumber());
                System.out.println("HAND : "+te.getNumberOfHand());
                System.out.println("Truco Player : "+te.getTrucoPlayer().getName());
                System.out.println("TYPE  : "+te.getTypeEvent());
                System.out.println("LA CARTA   PALO = "+te.getCard().getKind()+" El valor es "+te.getCard().getValue());
                
            }
        }
    }
    public void xmlReadCanto(Object o) {
        String aux;
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            if(aux.compareTo("Type")==0) {
                typeAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            if(aux.compareTo("Table")==0) {
                //System.out.println("MESSAGE:"+element.getText());
                tableIdAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            if(aux.compareTo("Hand")==0) {
                handAux=Integer.parseInt(element.getAttributeValue("number"));
            }
            if(aux.compareTo("Player")==0) {
                //System.out.println("PLAYER:"+element.getText());
                userAux=element.getAttributeValue("name");
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadCanto(child);
            }
            if(aux.compareTo("Canto")==0) {
                TrucoEvent te=new TrucoEvent(tableIdAux,handAux,mi_jugador,(byte)typeAux);
                System.out.println("Tabla :"+ te.getTableNumber());
                System.out.println("HAND : "+te.getNumberOfHand());
                System.out.println("Truco Player : "+te.getTrucoPlayer().getName());
                System.out.println("TYPE  : "+te.getTypeEvent());
                                /*	try {
                                                    String tableid=String.valueOf(tableIdAux);
                                                    Table tabela = (Table)getTables().get(tableid);
                                                        TrucoGameClient trucoGame=(TrucoGameClient)tabela.getTGame();
                                                        trucoGame.play(te);
                                        } catch (java.lang.NullPointerException e) {
                                                        System.err.println("LA TABLA ES NULL EN EL COMUNICATOR CLIENT METODO xmlReadCantarTanto ");
                                                        e.printStackTrace();
                                                                throw e;
                                        }*/
            }
        }
    }
    
    int tableIdAux;
    int handAux;
    TrucoCard []cartas=new TrucoCard[3];
    int currentCard=0;
    String userAux;
    public void xmlreadSendCards(Object o) {
        tableIdAux=0;
        handAux=0;
        currentCard=0;
        xmlreadSendCardsAlg(o);
        
        
    }
    
    public void xmlreadSendCardsAlg(Object o) {
        String aux;
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            if(aux.compareTo("TrucoPlayer")==0) {
                //System.out.println("PLAYER:"+element.getText());
                userAux=element.getAttributeValue("name");
            }
            if(aux.compareTo("Table")==0) {
                //System.out.println("MESSAGE:"+element.getText());
                tableIdAux=Integer.parseInt(element.getAttributeValue("id"));
            }
            if(aux.compareTo("Hand")==0) {
                handAux=Integer.parseInt(element.getAttributeValue("number"));
            }
            if(aux.compareTo("Carta")==0) {
                String kind=new String();
                String value=new String();
                kind=element.getAttributeValue("kind");
                value=element.getAttributeValue("value");
                cartas[currentCard]=new TrucoCard(Integer.parseInt(kind),Integer.parseInt(value));
                currentCard++;
                
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlreadSendCardsAlg(child);
            }
            if(aux.compareTo("SendCards")==0) {
                //Chatpanel.showChatMessage(user,message);
                TrucoEvent te=new TrucoEvent(tableIdAux,handAux,mi_jugador,TrucoEvent.ENVIAR_CARTAS,cartas);
                System.out.println("tableID: " + (te.getTableNumber()) + "\nHand" + te.getNumberOfHand() +"\nPlayer :" + (te.getPlayer()).getName());
                TrucoCard []cartasIMP=new TrucoCard[3];
                System.out.println("*******Cartas*********");
                cartasIMP=te.getCards();
                for(int i=0;i<3;i++) {
                    System.out.println("Palo:" + cartasIMP[i].getKind() + "Value: " + cartasIMP[i].getValue());
                    
                }
                
                //ESTO HAY QUE DESCOMENTAR PARA QUE ANDE COMENTADO
                                                /*	try {
                                                            String tableid=String.valueOf(tableIdAux);
                                                                    Table tabela = (Table)getTables().get(tableid);
                                                                        TrucoGameClient trucoGame=(TrucoGameClient)tabela.getTGame();
                                                                        trucoGame.play(te);
                                                 
                                                                } catch (java.lang.NullPointerException e) {
                                                                        System.err.println("LA TABLA ES NULL EN EL COMUNICATOR CLIENT METODO xmlreadSendCardsAlg ");
                                                                        e.printStackTrace();
                                                                throw e;
                                                        }*/
                
                
            }
        }
    }
    public void play(TrucoEvent event){}
    public void turn(TrucoEvent event){}
    public void endOfHand(TrucoEvent event){}
    public void cardsDeal(TrucoEvent event){}
    public void handStarted(TrucoEvent event){}
    public void gameStarted(TrucoEvent event){}
    public void endOfGame(TrucoEvent event){}
    public void play(TrucoPlay tp) {
        Document doc=tp.toXml();
        super.sendXmlPackage(doc);
    }
    public TrucoPlayer getAssociatedPlayer(){return mi_jugador;}
    
    int posAux;//solo sirve para este metodo el de abajo xmlReadPlayerSitRequest
    int idAux;//solo sirve para el metodo de abajo xmlReadPlayerSitRequest
    String userAux2;
    public void xmlReadPlayerSit(Object o) {//en verdad jugador no se usa porque creemos que como el communicator ya tiene su player entonces con
        //ese player es suficiente
        String aux;
        
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            
            if(aux.compareTo("Pos")==0) {
                posAux=Integer.parseInt(element.getAttributeValue("pos"));
                
            }
            if(aux.compareTo("Player")==0) {
                userAux2=element.getAttributeValue("name");
                
            }
            if(aux.compareTo("Table")==0) {
                
                idAux=Integer.parseInt(element.getAttributeValue("id"));
                
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadPlayerSit(child);
            }
            if(aux.compareTo("PlayerSit")==0) {
                System.out.println("Dentro del Communicator Client xmlReadPlayerSit");
                System.out.println("El table a sentarse es"+idAux);
                System.out.println("La posicion es"+posAux);
                try {
                    String tableid=String.valueOf(idAux);
                    Table tabela = (Table)getTables().get(tableid);
                    
                    tabela.sitPlayer(pieza.getPlayer(userAux2),posAux);
                } catch (java.lang.NullPointerException e) {
                    System.err.println("LA TABLA ES NULL EN EL COMUNICATOR CLIENT METODO xmlReadPlayerSit ");
                    e.printStackTrace();
                    throw e;
                }
            }
            
        }
    }
    
    public void xmlReadUserJoined(Object o){
        String aux;
        System.err.println("Estamos dentro de xmlReadUserJoines-------------------------------");
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            
            if(aux.compareTo("Player")==0) {
                System.err.println("Estamos dentro de xmlReadUserJoines//////  dentro de un player=======================================");
                String jugname=element.getAttributeValue("name");
                int rating=Integer.parseInt(element.getAttributeValue("rating"));
                if(mi_jugador== null) {
                    mi_jugador= new TrucoPlayer(jugname,rating);
                    pieza.addPlayer(mi_jugador);
                    System.out.println("Jugador nuevo name="+mi_jugador.getName()+"rating"+mi_jugador.getRating());
                    pieza.loginCompleted(mi_jugador);
                    setPlayer(mi_jugador);
                }
                else {
                    pieza.addPlayer(new TrucoPlayer(jugname, rating));
                }
                
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadUserJoined(child);
            }
        }
    }
    
    String playerAux;
    String tableidAux;
    String playerAux4;
    String tableidAux4;
    public void xmlReadTableJoined(Object o){
        String aux;
        System.err.println("Estamos dentro de xmlReadTableJoined-------------------------------");
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            
            if(aux.compareTo("Player")==0) {
                System.err.println("Estamos dentro de xmlReadTableJoined//////  dentro de un player=======================================");
                playerAux4=element.getAttributeValue("name");
            }
            if(aux.equals("Table")) {
                tableidAux4=element.getAttributeValue("id");
            }
            
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadTableJoined(child);
            }
            
            if (aux.equals("TableJoined")) {
                // Hacer lo que hay que hacer
                Table t = (Table)getTables().get(tableidAux4);
                TrucoPlayer tp = (TrucoPlayer)pieza.getPlayer(playerAux4);
                System.out.println("Voy a hacer un t.addPlayer de " + tp.getName());
                t.addPlayer(tp);
                
                if (getAssociatedPlayer().getName().equals(tp.getName())) {
                    t.show();
                }
            }
        }
    }
    
    public void xmlReadTableCreated(Object o){
        String aux;
        
        if (o instanceof Element) {
            System.out.println("Cricco morgue: " + ((Element)o).getName());
            Element element = (Element) o;
            aux=element.getName();
            if(aux.equals("Player")) {
                playerAux=element.getAttributeValue("name");
            }
            if(aux.equals("Table")) {
                
                tableidAux=element.getAttributeValue("id");
                
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadTableCreated(child);
            }
            if(aux.equals("TableCreated")) {
                
                Table t = null;
                TrucoPlayer tp = pieza.getPlayer(playerAux);
                
                
                if (getAssociatedPlayer().getName().equals(tp.getName())) {
                    t = new Table(getAssociatedPlayer(), true);
                    t.setTableNumber(Integer.parseInt(tableidAux));
                    t.addTableListener(this);
                    getTables().put(tableidAux, t);
                    System.out.println("En el cliente, voy a crear un table.!");
                    this.pieza.addTable(t);
                    t.addPlayer(tp);
                    
                    t.show();
                } else {
                    t = new Table(getAssociatedPlayer(), false);
                    t.setTableNumber(Integer.parseInt(tableidAux));
                    t.addTableListener(this);
                    getTables().put(tableidAux, t);
                    System.out.println("En el cliente, voy a crear un table.!");
                    this.pieza.addTable(t);
                    t.addPlayer(tp);
                }
                
            }
        }
    }
    
    
    public void xmlReadLoginOk(Object o) {
        Players.removeAllElements();
        Mesas.removeAllElements();
        current=0;
        xmlReadLoginAlg(o);
    }
    
    
    
    
    private  void xmlReadLoginAlg(Object o) {//
        String aux;
        
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            System.out.println("Estamos dentro del xmlReadLoginAlg");
            if(aux.compareTo("Player")==0) {
                String jugname=element.getAttributeValue("name");
                int rating=Integer.parseInt(element.getAttributeValue("rating"));
                TrucoPlayer jug1=new TrucoPlayer(jugname,rating);
                Players.add(jug1);
                System.out.println("Player"+ jugname);
            }
            if(aux.compareTo("Playert")==0) {
                String jugname=element.getAttributeValue("name");
                //System.out.println("Playert:  "+jugname);
                TrucoPlayer jugaux=new TrucoPlayer(jugname,0);
                ((Table)(Mesas.get(current))).addPlayer(jugaux);
                //mesa.addPlayer(jugaux);
            }
            if(aux.compareTo("Table")==0) {
/*                Table mesa=new Table();
                int number=Integer.parseInt(element.getAttributeValue("number"));
                mesa.setTableNumber(number);
                current=Mesas.size();
                Mesas.add(mesa); */
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadLoginAlg(child);
            }
            if(aux.compareTo("LoginOk")==0) {
                
                TrucoPlayer jug;
                Table mesa1;
                for (Enumeration e = Players.elements() ; e.hasMoreElements() ;) {
                    jug=(TrucoPlayer)e.nextElement();
                    System.out.println("================= RECIBI Player: "+jug.getName()+" Rating: "+jug.getRating()+"\n");
                    
                    if (!jug.getName().equals(getAssociatedPlayer().getName()))
                        pieza.addPlayer(jug);
                }
                for (Enumeration e = Mesas.elements() ; e.hasMoreElements() ;) {
                    mesa1=(Table)e.nextElement();
                    System.out.println("==================  RECIBI Table number: "+mesa1.getTableNumber()+"\n");
                    Vector jugadores=(Vector)mesa1.getPlayers();
                    /*for(Enumeration e2=jugadores.elements();e2.hasMoreElements();) {
                        jug=(Player)e2.nextElement();
                        System.out.println("======================RECIBI Player: "+jug.getName()+" Rating: "+jug.getRating()+"\n");
                    }*/
                    
                    pieza.addTable(mesa1);
                    
                }
            }//el if cuando termina de leer el paquete
        }
        
    }
    
    
    /** <p>
     * Does ...
     * </p><p>
     *
     * @param chatPanelContainer ...
     * </p><p>
     * @param player ...
     * </p><p>
     * @param htmlMessage ...
     * </p><p>
     *
     * </p>
     *
     */
    
    /** <p>
     * Does ...
     * </p><p>
     *
     * </p>
     *
     */
    public void gameStartRequested() {
    }
    
    public void gameStartRequest(TableEvent te) {
        System.out.println("Imprim� ya algo en gameStartRequest del CC");
        Document doc=te.toXml();
        super.sendXmlPackage(doc);
        
    }
    String equipoAux1; //
    String equipoAux2; //
    public void xmlReadGameStarted(Object o) {// PAULO
        String aux;
        
        if (o instanceof Element) {
            Element element = (Element) o;
            aux=element.getName();
            
            if(aux.compareTo("Equipo1")==0) {
                equipoAux1 = element.getAttributeValue("equipo1");
            }
            
            if(aux.compareTo("Equipo2")==0) {
                equipoAux2 = element.getAttributeValue("equipo2");
            }
            if(aux.compareTo("Table")==0) {
                idAux=Integer.parseInt(element.getAttributeValue("id"));
                System.out.println("El id de la tabla es:"+element.getAttributeValue("id"));
            }
            List children = element.getContent();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                Object child = iterator.next();
                xmlReadGameStarted(child);
            }
            if(aux.compareTo("GameStarted")==0) {
                System.out.println("Equipo1 :"+equipoAux1);
                System.out.println("Equipo2: "+equipoAux2);
                System.out.println("Table : "+idAux);
                //ESTO ESTA COMENTADO PORQUE hay metodos no implementados todavia en el TableServer
                /* try {
                    Table tabela = (Table)getTables().get(idAux);
                 
     Team team1=new Team(equipoAux1);
     Team team2=new Team(equipoAux1);
     TrucoGame truco=new TrucoGame(team1,team2);
     tabela.startGame(truco);
     } catch (java.lang.NullPointerException e) {
     System.e.println("LA TABLA ES NULL EN EL COMUNICATOR CLIENT EN EL METODO xmlReadGameStarted");
     e.printStackTrace();
     throw e;
                }*/
                TrucoGame tGame;
                TrucoTeam tTeams[];
                
                System.out.println("Requesting client game start...");
                
                Table t = (Table)(getTables().get(String.valueOf(idAux)));
                tTeams = t.createTeams();
                
                // se crea el TrucoGame con los teams creados
                tGame = new TrucoGameClient(tTeams[0], tTeams[1]);
                
                // se llama al 'startGame' de todas las tablas
                t.startGame(tGame);
                // da la orden de inicio de juego a 'tGame'
                tGame.startGame();
                
                
            }
        }
        
    }
    public void chatMessageSent(ChatPanelContainer cpc, TrucoPlayer player, String htmlMessage) {
        
    }
    
    /** Getter for property player.
     * @return Value of property player.
     *
     */
    public TrucoPlayer getPlayer() {
        return this.mi_jugador;
    }
    
    /** Setter for property player.
     * @param player New value of property player.
     *
     */
    public void setPlayer(TrucoPlayer player) {
        this.player = player;
    }
    
    /** <p>
     * Does ...
     * </p><p>
     *
     * @param ev ...
     * </p><p>
     *
     * </p>
     *
     */
    public void createTableRequested(RoomEvent ev) {
        //peticion de createTable
        System.out.println("Estoy en el CC: createTableRequested");
        Document doc;
        doc = super.xmlCreateTableRequested(ev);
        super.sendXmlPackage(doc);
    }
    public Document xmlCreateTableJoinRequested(RoomEvent te) {
        Element ROOT = new Element("TableJoinRequest");
        Element PLAYER=new Element("Player");
        Element TABLE = new Element("Table");
        //mi_jugador=new TrucoPlayer("Dani",10);
        
        PLAYER.setAttribute("name",te.getPlayer().getName());
        
        TABLE.setAttribute("id",String.valueOf(te.getTableNumber()));
        ROOT.addContent(PLAYER);
        ROOT.addContent(TABLE);
        
        Document doc = new Document(ROOT);
        return doc;
    }
    public void tableJoinRequested(RoomEvent ev) {
        Document doc=xmlCreateTableJoinRequested(ev);
        super.sendXmlPackage(doc);
    }
    public void gameFinished(TableEvent event) {
    }
    
    public void gameStarted(TableEvent event) {
    }
    
    public void playerKickRequest(TableEvent event) {
    }
    
    public void playerKicked(TableEvent event) {
    }
    
    public void playerSit(TableEvent event) {
    }
    
    public void playerSitRequest(TableEvent event) {
        Document doc=event.toXml();
        super.sendXmlPackage(doc);
    }
    
    public void playerStandRequest(TableEvent event) {
    }
    
    public void playerStanded(TableEvent event) {
    }
    
    public void showPlayed(TableEvent event) {
    }
    
    public void signSendRequest(TableEvent event) {
    }
    
    public void playerJoined(TrucoPlayer player) {
        
    }
    
    public void signSent(TableEvent event) {
    }
    
      /*  public static void main(String[] args)
        {
                RoomEvent te=new RoomEvent();
                                te.setTableNumber(10);
       
                CommunicatorClient cc=new CommunicatorClient();
                                Document doc=cc.xmlCreateTableJoinRequested(te);
                try {
       
                XMLOutputter serializer = new XMLOutputter("  ", true);
       
                serializer.output(doc, System.out);
       
                        }
                catch (IOException e) {
                System.err.println(e);
                }
                //        cc.cabecera(doc);
        }*/
    
}
