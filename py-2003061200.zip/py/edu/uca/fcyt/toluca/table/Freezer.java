/*
 * Freezer.java
 *
 * Created on March 27, 2003, 9:51 PM
 */

package py.edu.uca.fcyt.toluca.table;

/**
 *
 * @author  ale
 */
class Freezer {
    
    /** Creates a new instance of Freezer */
    public Freezer() {
    }
    
    //public static final String IMAGES_LOCATION=System.getProperty("user.dir") + System.getProperty("file.separator");
    public static final String IMAGES_LOCATION="C:/Documents and Settings/Owner/My Documents/poo/table1/dd/probaaa/imagenes/";
    public static final String SEPARATOR = System.getProperty("file.separator");
    public static final int ENVIDO = 123;
    public static final int TRUCO = 124;

}
