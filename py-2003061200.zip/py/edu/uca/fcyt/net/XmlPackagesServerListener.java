/*
 * XmlPackagesServerListener.java
 *
 * Created on 25 de marzo de 2003, 08:14 PM
 */

package py.edu.uca.fcyt.net;

/**
 *
 * @author  PABLO JAVIER
 */
public interface XmlPackagesServerListener {
    public void SessionStarted(XmlPackagesSession xps);
    
}

