/*
 * XmlPackage.java
 *
 * Created on 8 de noviembre de 2002, 9:33
 */

package py.edu.uca.fcyt.xml;

/**
 *
 * @author  psanta
 */
public interface XmlPackage {
    public String getTheXml();
}