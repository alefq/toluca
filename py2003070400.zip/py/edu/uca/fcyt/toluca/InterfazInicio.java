package py.edu.uca.fcyt.toluca;

import javax.swing.*;


public class InterfazInicio extends JApplet{
	
}