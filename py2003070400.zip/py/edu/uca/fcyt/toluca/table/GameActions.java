package py.edu.uca.fcyt.toluca.table;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

class GameActions implements MouseListener {
    public GameActions() {
        //El constructor void "()" por omision llama al consturctor super()
        //
        //super();
    }
    
    public void mouseClicked(MouseEvent e) {
    }
    
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    
}